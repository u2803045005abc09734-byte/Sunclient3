package de.sunclient.mixin;

import de.sunclient.Freelook;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Freelook: Mausbewegung geht an die Kamera statt an den Spieler. */
@Mixin(class_1297.class)
public class EntityMixin {
	@Inject(method = "turn", at = @At("HEAD"), cancellable = true, require = 0)
	private void sunclient$turn(double yRot, double xRot, CallbackInfo ci) {
		if (Freelook.active && (Object) this == class_310.method_1551().field_1724) {
			Freelook.turn(yRot, xRot);
			ci.cancel();
		}
	}
}
