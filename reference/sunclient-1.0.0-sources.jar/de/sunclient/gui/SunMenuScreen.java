package de.sunclient.gui;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

/** Hauptmenue (Standard: Rechte Shift-Taste). */
public class SunMenuScreen extends SunScreen {

	public SunMenuScreen(class_437 parent) {
		super("Sun Client", parent);
	}

	@Override
	protected void method_25426() {
		int cx = this.field_22789 / 2 - 110;
		int y = this.field_22790 / 2 - 62;
		int step = 26;

		addButton("HUD-Positionen bearbeiten", cx, y, 220, () -> mc().method_1507(new HudEditorScreen(this)));
		addButton("HUD-Module an/aus", cx, y + step, 220, () -> mc().method_1507(new ModulesScreen(this)));
		addButton("Funktionen (Zoom, Sprint, Freelook ...)", cx, y + 2 * step, 220,
			() -> mc().method_1507(new FeaturesScreen(this)));
		addButton("Resource Packs von Modrinth", cx, y + 3 * step, 220,
			() -> mc().method_1507(new PackBrowserScreen(this)));
		addButton("Fertig", cx, y + 4 * step + 8, 220, this::method_25419);
	}

	@Override
	public void method_25394(class_332 g, int mouseX, int mouseY, float delta) {
		super.method_25394(g, mouseX, mouseY, delta);
		g.method_27534(this.field_22793,
			class_2561.method_43470("Zoom: C (halten)  |  Toggle Sprint: R  |  Freelook: Alt (halten)"),
			this.field_22789 / 2, this.field_22790 / 2 + 70, 0xFFAAAAAA);
	}
}
