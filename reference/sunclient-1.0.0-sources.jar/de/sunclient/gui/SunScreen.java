package de.sunclient.gui;

import de.sunclient.SunConfig;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Basis fuer alle Sun-Client-Menues: Titel, Button-Helfer, Zurueck-Verhalten. */
public abstract class SunScreen extends class_437 {
	protected final class_437 parent;

	protected SunScreen(String title, class_437 parent) {
		super(class_2561.method_43470(title));
		this.parent = parent;
	}

	protected static class_310 mc() {
		return class_310.method_1551();
	}

	protected class_4185 addButton(String label, int x, int y, int w, Runnable action) {
		return method_37063(class_4185.method_46430(class_2561.method_43470(label), b -> action.run())
			.method_46434(x, y, w, 20).method_46431());
	}

	protected void toggle(int x, int y, int w, String name, BooleanSupplier get, Consumer<Boolean> set) {
		class_4185[] ref = new class_4185[1];
		ref[0] = addButton(label(name, get.getAsBoolean()), x, y, w, () -> {
			boolean now = !get.getAsBoolean();
			set.accept(now);
			ref[0].method_25355(class_2561.method_43470(label(name, now)));
			SunConfig.save();
		});
	}

	private static String label(String name, boolean on) {
		return name + ": " + (on ? "AN" : "AUS");
	}

	@Override
	public void method_25394(class_332 g, int mouseX, int mouseY, float delta) {
		super.method_25394(g, mouseX, mouseY, delta);
		g.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 14, 0xFFFFC107);
	}

	@Override
	public void method_25419() {
		SunConfig.save();
		mc().method_1507(parent);
	}
}
