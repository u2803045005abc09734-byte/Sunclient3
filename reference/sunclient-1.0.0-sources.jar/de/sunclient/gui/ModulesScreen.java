package de.sunclient.gui;

import de.sunclient.hud.HudManager;
import de.sunclient.hud.HudModule;
import net.minecraft.class_437;

/** HUD-Module einzeln an- und ausschalten. */
public class ModulesScreen extends SunScreen {

	public ModulesScreen(class_437 parent) {
		super("HUD-Module", parent);
	}

	@Override
	protected void method_25426() {
		int left = this.field_22789 / 2 - 155;
		int right = this.field_22789 / 2 + 5;
		int top = 40;
		int step = 24;

		int i = 0;
		for (HudModule m : HudManager.MODULES) {
			int x = (i % 2 == 0) ? left : right;
			int y = top + (i / 2) * step;
			toggle(x, y, 150, m.name, m::isEnabled, m::setEnabled);
			i++;
		}

		int rows = (HudManager.MODULES.size() + 1) / 2;
		int by = top + rows * step + 8;
		addButton("Alle Positionen zuruecksetzen", this.field_22789 / 2 - 100, by, 200, () -> {
			for (HudModule m : HudManager.MODULES) m.resetPosition();
		});
		addButton("Zurueck", this.field_22789 / 2 - 100, by + 26, 200, this::method_25419);
	}
}
