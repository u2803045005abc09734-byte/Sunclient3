package de.sunclient.gui;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Resource Packs auf Modrinth suchen und direkt in den resourcepacks-Ordner laden. */
public class PackBrowserScreen extends SunScreen {
	private static final String MC_VERSION = "1.21.11";
	private static final int MAX_RESULTS = 6;
	private static final HttpClient HTTP = HttpClient.newBuilder()
		.followRedirects(HttpClient.Redirect.NORMAL)
		.connectTimeout(Duration.ofSeconds(10))
		.build();

	private record Hit(String id, String title, String author, long downloads) {}

	private static String lastQuery = "";

	private class_342 searchBox;
	private final List<class_4185> resultButtons = new ArrayList<>();
	private volatile List<Hit> hits = List.of();
	private volatile int version = 0;
	private int shownVersion = -1;
	private volatile String status = "Suchbegriff eingeben und auf Suchen klicken.";

	public PackBrowserScreen(class_437 parent) {
		super("Resource Packs (Modrinth)", parent);
	}

	@Override
	protected void method_25426() {
		resultButtons.clear();

		searchBox = new class_342(this.field_22793, this.field_22789 / 2 - 150, 36, 200, 20, class_2561.method_43470("Suche"));
		searchBox.method_1852(lastQuery);
		method_37063(searchBox);

		addButton("Suchen", this.field_22789 / 2 + 55, 36, 95, () -> search(searchBox.method_1882()));

		for (int i = 0; i < MAX_RESULTS; i++) {
			final int index = i;
			class_4185 b = addButton("", this.field_22789 / 2 - 150, 66 + i * 22, 300, () -> {
				List<Hit> current = hits;
				if (index < current.size()) download(current.get(index));
			});
			b.field_22764 = false;
			resultButtons.add(b);
		}

		addButton("Zurueck", this.field_22789 / 2 - 100, this.field_22790 - 28, 200, this::method_25419);

		shownVersion = -1;
		if (hits.isEmpty()) search(lastQuery);
	}

	private static String formatNumber(long n) {
		if (n >= 1_000_000) return (n / 100_000) / 10.0 + "M";
		if (n >= 1_000) return (n / 100) / 10.0 + "k";
		return String.valueOf(n);
	}

	private void search(String query) {
		lastQuery = query == null ? "" : query.trim();
		final String q = lastQuery;
		status = "Suche ...";
		CompletableFuture.runAsync(() -> {
			try {
				String facets = "[[\"project_type:resourcepack\"],[\"versions:" + MC_VERSION + "\"]]";
				String url = "https://api.modrinth.com/v2/search?query="
					+ URLEncoder.encode(q, StandardCharsets.UTF_8)
					+ "&facets=" + URLEncoder.encode(facets, StandardCharsets.UTF_8)
					+ "&limit=" + MAX_RESULTS
					+ (q.isEmpty() ? "&index=downloads" : "");
				String body = get(url);
				JsonObject root = JsonParser.parseString(body).getAsJsonObject();
				JsonArray arr = root.getAsJsonArray("hits");
				List<Hit> result = new ArrayList<>();
				for (JsonElement el : arr) {
					JsonObject o = el.getAsJsonObject();
					result.add(new Hit(
						o.get("project_id").getAsString(),
						o.get("title").getAsString(),
						o.has("author") ? o.get("author").getAsString() : "?",
						o.has("downloads") ? o.get("downloads").getAsLong() : 0L));
				}
				hits = result;
				version++;
				status = result.isEmpty()
					? "Nichts gefunden."
					: "Auf ein Pack klicken, um es herunterzuladen.";
			} catch (Exception e) {
				status = "Fehler bei der Suche: " + e.getMessage();
			}
		});
	}

	private void download(Hit hit) {
		status = "Lade " + hit.title() + " ...";
		CompletableFuture.runAsync(() -> {
			try {
				String gv = URLEncoder.encode("[\"" + MC_VERSION + "\"]", StandardCharsets.UTF_8);
				String body = get("https://api.modrinth.com/v2/project/" + hit.id() + "/version?game_versions=" + gv);
				JsonArray versions = JsonParser.parseString(body).getAsJsonArray();
				if (versions.isEmpty()) {
					status = "Keine Version fuer " + MC_VERSION + " gefunden.";
					return;
				}
				JsonArray files = versions.get(0).getAsJsonObject().getAsJsonArray("files");
				JsonObject chosen = null;
				for (JsonElement el : files) {
					JsonObject f = el.getAsJsonObject();
					if (chosen == null) chosen = f;
					if (f.has("primary") && f.get("primary").getAsBoolean()) {
						chosen = f;
						break;
					}
				}
				if (chosen == null) {
					status = "Keine Datei gefunden.";
					return;
				}
				String fileUrl = chosen.get("url").getAsString();
				String fileName = chosen.get("filename").getAsString().replaceAll("[\\\\/:*?\"<>|]", "_");

				Path dir = FabricLoader.getInstance().getGameDir().resolve("resourcepacks");
				Files.createDirectories(dir);
				Path target = dir.resolve(fileName);
				Path tmp = dir.resolve(fileName + ".part");

				HttpRequest req = HttpRequest.newBuilder(URI.create(fileUrl))
					.header("User-Agent", "SunClient/1.0 (Fabric mod)")
					.timeout(Duration.ofMinutes(5))
					.GET().build();
				HttpResponse<Path> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofFile(tmp));
				if (resp.statusCode() != 200) {
					Files.deleteIfExists(tmp);
					status = "Download fehlgeschlagen (HTTP " + resp.statusCode() + ").";
					return;
				}
				Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);

				status = "Fertig: " + fileName + " - jetzt unter Optionen > Ressourcenpakete aktivieren.";
				class_310 mc = class_310.method_1551();
				mc.execute(() -> mc.method_1520().method_14445());
			} catch (Exception e) {
				status = "Fehler beim Download: " + e.getMessage();
			}
		});
	}

	private static String get(String url) throws Exception {
		HttpRequest req = HttpRequest.newBuilder(URI.create(url))
			.header("User-Agent", "SunClient/1.0 (Fabric mod)")
			.timeout(Duration.ofSeconds(15))
			.GET().build();
		HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
		if (resp.statusCode() != 200) throw new IllegalStateException("HTTP " + resp.statusCode());
		return resp.body();
	}

	@Override
	public void method_25394(class_332 g, int mouseX, int mouseY, float delta) {
		// Ergebnisliste in die Buttons uebernehmen, sobald neue Ergebnisse da sind
		if (shownVersion != version) {
			List<Hit> current = hits;
			for (int i = 0; i < resultButtons.size(); i++) {
				class_4185 b = resultButtons.get(i);
				if (i < current.size()) {
					Hit h = current.get(i);
					String text = h.title() + "  -  " + h.author() + "  (" + formatNumber(h.downloads()) + " Downloads)";
					if (text.length() > 52) text = text.substring(0, 49) + "...";
					b.method_25355(class_2561.method_43470(text));
					b.field_22764 = true;
				} else {
					b.field_22764 = false;
				}
			}
			shownVersion = version;
		}

		super.method_25394(g, mouseX, mouseY, delta);
		g.method_27534(this.field_22793, class_2561.method_43470(status), this.field_22789 / 2, this.field_22790 - 46, 0xFFFFFFFF);
	}
}
